"""
Flask App Components — Helpers e Decoradores Reutilizáveis
Copie os trechos necessários para o seu projeto.
"""

# ─────────────────────────────────────────────
# 1. DECORADORES DE VIEW
# ─────────────────────────────────────────────

from functools import wraps
from flask import session, redirect, url_for, abort, request, jsonify, g, current_app


def login_required(f):
    """Exige que o usuário esteja logado. Redireciona para /auth/login."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('usuario_id'):
            return redirect(url_for('auth.login', next=request.path))
        return f(*args, **kwargs)
    return decorated


def requer_papel(*papeis):
    """Exige que o usuário tenha um dos papéis especificados.
    Uso: @requer_papel('admin', 'moderador')
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not g.usuario:
                abort(401)
            if g.usuario.papel not in papeis:
                abort(403)
            return f(*args, **kwargs)
        return decorated
    return decorator


def apenas_ajax(f):
    """Rejeita requisições que não sejam AJAX/fetch."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not request.is_json and not request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            abort(400, 'Esta rota aceita apenas requisições AJAX.')
        return f(*args, **kwargs)
    return decorated


def cachear(segundos=300):
    """Adiciona header Cache-Control na resposta.
    Uso: @cachear(60)  # cache de 1 minuto
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            resp = f(*args, **kwargs)
            if hasattr(resp, 'headers'):
                resp.headers['Cache-Control'] = f'public, max-age={segundos}'
            return resp
        return decorated
    return decorator


# ─────────────────────────────────────────────
# 2. HELPERS DE RESPOSTA
# ─────────────────────────────────────────────

def resposta_sucesso(dados=None, mensagem='Operação realizada com sucesso.', status=200):
    """Resposta JSON padronizada de sucesso."""
    payload = {'sucesso': True, 'mensagem': mensagem}
    if dados is not None:
        payload['dados'] = dados
    return jsonify(payload), status


def resposta_erro(mensagem='Erro inesperado.', detalhes=None, status=400):
    """Resposta JSON padronizada de erro."""
    payload = {'sucesso': False, 'erro': mensagem}
    if detalhes:
        payload['detalhes'] = detalhes
    return jsonify(payload), status


# ─────────────────────────────────────────────
# 3. PAGINAÇÃO
# ─────────────────────────────────────────────

class Paginacao:
    """Paginação manual para uso com SQLite puro (sem SQLAlchemy)."""

    def __init__(self, total, pagina, por_pagina=12):
        self.total = total
        self.page = max(1, pagina)
        self.per_page = por_pagina
        self.pages = max(1, -(-total // por_pagina))
        self.has_prev = self.page > 1
        self.has_next = self.page < self.pages
        self.prev_num = self.page - 1
        self.next_num = self.page + 1
        self.offset = (self.page - 1) * por_pagina

    def iter_pages(self, left_edge=1, right_edge=1, left_current=2, right_current=2):
        last = 0
        for num in range(1, self.pages + 1):
            in_range = (
                num <= left_edge or
                (self.page - left_current <= num <= self.page + right_current) or
                num > self.pages - right_edge
            )
            if in_range:
                if last + 1 != num:
                    yield None
                yield num
                last = num


# ─────────────────────────────────────────────
# 4. VALIDAÇÃO DE FORMULÁRIOS (sem WTForms)
# ─────────────────────────────────────────────

class ValidadorForm:
    """Validação simples de dados de formulário."""

    def __init__(self, dados: dict):
        self.dados = dados
        self.erros = {}

    def obrigatorio(self, campo, label=None):
        label = label or campo
        if not self.dados.get(campo, '').strip():
            self.erros[campo] = f'{label} é obrigatório.'
        return self

    def email(self, campo, label='Email'):
        import re
        valor = self.dados.get(campo, '')
        if valor and not re.match(r'^[^@]+@[^@]+\.[^@]+$', valor):
            self.erros[campo] = f'{label} inválido.'
        return self

    def min_len(self, campo, minimo, label=None):
        label = label or campo
        valor = self.dados.get(campo, '')
        if valor and len(valor) < minimo:
            self.erros[campo] = f'{label} deve ter ao menos {minimo} caracteres.'
        return self

    def max_len(self, campo, maximo, label=None):
        label = label or campo
        valor = self.dados.get(campo, '')
        if valor and len(valor) > maximo:
            self.erros[campo] = f'{label} deve ter no máximo {maximo} caracteres.'
        return self

    def numerico(self, campo, label=None):
        label = label or campo
        valor = self.dados.get(campo, '')
        try:
            float(valor)
        except (ValueError, TypeError):
            self.erros[campo] = f'{label} deve ser um número.'
        return self

    @property
    def valido(self):
        return len(self.erros) == 0


# Uso:
# v = ValidadorForm(request.form)
# v.obrigatorio('nome', 'Nome').email('email').min_len('senha', 6, 'Senha')
# if not v.valido:
#     return render_template('form.html', erros=v.erros), 422


# ─────────────────────────────────────────────
# 5. UPLOAD SEGURO
# ─────────────────────────────────────────────

import os
import uuid
from werkzeug.utils import secure_filename


EXTENSOES_IMAGEM = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
EXTENSOES_DOCUMENTO = {'pdf', 'docx', 'xlsx', 'csv', 'txt'}


def salvar_arquivo(arquivo, subpasta='uploads', extensoes=None):
    """
    Salva FileStorage com nome seguro + UUID.
    Retorna nome do arquivo salvo ou None se inválido.
    """
    if not arquivo or not arquivo.filename:
        return None

    ext = arquivo.filename.rsplit('.', 1)[-1].lower() if '.' in arquivo.filename else ''

    if extensoes and ext not in extensoes:
        return None

    nome = f"{uuid.uuid4().hex}.{ext}"
    pasta = os.path.join(current_app.config['UPLOAD_FOLDER'], subpasta)
    os.makedirs(pasta, exist_ok=True)
    arquivo.save(os.path.join(pasta, nome))
    return nome


def deletar_arquivo(nome, subpasta='uploads'):
    """Remove arquivo do disco com segurança."""
    if not nome:
        return
    caminho = os.path.join(current_app.config['UPLOAD_FOLDER'], subpasta, secure_filename(nome))
    if os.path.exists(caminho):
        os.remove(caminho)


# ─────────────────────────────────────────────
# 6. FILTROS JINJA2 PARA REGISTRAR NA APP
# ─────────────────────────────────────────────

def registrar_filtros(app):
    """Registra filtros customizados no Jinja2. Chamar em create_app()."""

    @app.template_filter('brl')
    def format_brl(value):
        """Formata número como moeda BRL: R$ 1.299,90"""
        try:
            return f'R$ {float(value):,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
        except (TypeError, ValueError):
            return 'R$ 0,00'

    @app.template_filter('data_br')
    def format_data_br(value):
        """Formata data como DD/MM/AAAA."""
        if value:
            try:
                return value.strftime('%d/%m/%Y')
            except AttributeError:
                return str(value)
        return ''

    @app.template_filter('data_hora_br')
    def format_data_hora_br(value):
        """Formata datetime como DD/MM/AAAA HH:MM."""
        if value:
            try:
                return value.strftime('%d/%m/%Y %H:%M')
            except AttributeError:
                return str(value)
        return ''

    @app.template_filter('plural')
    def plural(value, singular, plural_form):
        """Ex: {{ total | plural('item', 'itens') }}"""
        return singular if int(value) == 1 else plural_form

    @app.template_filter('destaque')
    def destaque(s, termo):
        """Destaca ocorrências de 'termo' em 's' com <mark>."""
        from markupsafe import Markup, escape
        if not termo:
            return s
        s_esc = str(escape(s))
        t_esc = str(escape(termo))
        return Markup(s_esc.replace(t_esc, f'<mark>{t_esc}</mark>'))
