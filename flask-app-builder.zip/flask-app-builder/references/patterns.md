# Flask Patterns Reference

## 1. Autenticação com Sessão (sem extensão)

```python
# app/blueprints/auth/routes.py
from flask import Blueprint, render_template, redirect, url_for, flash, session, request, g
from werkzeug.security import check_password_hash
from app.models import Usuario
from app.extensions import db

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.before_app_request
def carregar_usuario():
    usuario_id = session.get('usuario_id')
    g.usuario = Usuario.query.get(usuario_id) if usuario_id else None

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if g.usuario:
        return redirect(url_for('main.index'))

    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        usuario = Usuario.query.filter_by(email=email).first()

        if usuario and usuario.verificar_senha(senha):
            session.clear()
            session['usuario_id'] = usuario.id
            session.permanent = True
            flash(f'Bem-vindo, {usuario.nome}!', 'success')
            proximo = request.args.get('next')
            return redirect(proximo or url_for('main.index'))

        flash('Email ou senha incorretos.', 'danger')

    return render_template('auth/login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']

        if Usuario.query.filter_by(email=email).first():
            flash('Email já cadastrado.', 'warning')
            return redirect(url_for('auth.cadastro'))

        usuario = Usuario(nome=nome, email=email)
        usuario.set_senha(senha)
        db.session.add(usuario)
        db.session.commit()
        flash('Conta criada! Faça login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/cadastro.html')
```

---

## 2. API REST com Flask

```python
# app/blueprints/api/routes.py
from flask import Blueprint, jsonify, request, abort
from app.models import Produto
from app.extensions import db

api_bp = Blueprint('api', __name__, url_prefix='/api/v1')

# Autenticação por token simples
def requer_token(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        if token != current_app.config['API_TOKEN']:
            return jsonify({'erro': 'Token inválido'}), 401
        return f(*args, **kwargs)
    return decorated

@api_bp.route('/produtos', methods=['GET'])
def listar_produtos():
    pagina = request.args.get('pagina', 1, type=int)
    por_pagina = request.args.get('por_pagina', 20, type=int)
    busca = request.args.get('busca', '')

    query = Produto.query
    if busca:
        query = query.filter(Produto.nome.ilike(f'%{busca}%'))

    paginacao = query.paginate(page=pagina, per_page=por_pagina)

    return jsonify({
        'itens': [p.to_dict() for p in paginacao.items],
        'total': paginacao.total,
        'paginas': paginacao.pages,
        'pagina_atual': pagina,
    })

@api_bp.route('/produtos/<int:id>', methods=['GET'])
def obter_produto(id):
    produto = Produto.query.get_or_404(id)
    return jsonify(produto.to_dict())

@api_bp.route('/produtos', methods=['POST'])
@requer_token
def criar_produto():
    dados = request.get_json()
    if not dados:
        abort(400, description='JSON inválido')

    if 'nome' not in dados:
        return jsonify({'erro': 'Campo "nome" é obrigatório'}), 422

    produto = Produto(nome=dados['nome'], preco=dados.get('preco', 0))
    db.session.add(produto)
    db.session.commit()
    return jsonify(produto.to_dict()), 201

@api_bp.route('/produtos/<int:id>', methods=['PUT'])
@requer_token
def atualizar_produto(id):
    produto = Produto.query.get_or_404(id)
    dados = request.get_json()
    if 'nome' in dados: produto.nome = dados['nome']
    if 'preco' in dados: produto.preco = dados['preco']
    db.session.commit()
    return jsonify(produto.to_dict())

@api_bp.route('/produtos/<int:id>', methods=['DELETE'])
@requer_token
def deletar_produto(id):
    produto = Produto.query.get_or_404(id)
    db.session.delete(produto)
    db.session.commit()
    return '', 204

# Handler de erros para API (retorna JSON)
@api_bp.errorhandler(404)
def api_not_found(e):
    return jsonify({'erro': str(e)}), 404

@api_bp.errorhandler(422)
def api_unprocessable(e):
    return jsonify({'erro': str(e)}), 422
```

---

## 3. Banco de Dados com SQLite (sem ORM)

```python
# app/db.py
import sqlite3
import click
from flask import current_app, g

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row  # acesso por nome: row['coluna']
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db: db.close()

def init_db():
    db = get_db()
    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf8'))

def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)

@click.command('init-db')
def init_db_command():
    """Inicializa o banco de dados."""
    init_db()
    click.echo('Banco inicializado.')
```

```sql
-- app/schema.sql
DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS produto;

CREATE TABLE usuario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    senha_hash TEXT NOT NULL,
    papel TEXT NOT NULL DEFAULT 'user',
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE produto (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descricao TEXT,
    preco REAL NOT NULL DEFAULT 0,
    estoque INTEGER NOT NULL DEFAULT 0,
    ativo INTEGER NOT NULL DEFAULT 1,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

```python
# Usar nas views
@main_bp.route('/produtos')
def listar_produtos():
    db = get_db()
    produtos = db.execute(
        'SELECT * FROM produto WHERE ativo = 1 ORDER BY nome'
    ).fetchall()
    return render_template('main/produtos.html', produtos=produtos)

@main_bp.route('/produto/novo', methods=['POST'])
def criar_produto():
    nome = request.form['nome']
    preco = float(request.form['preco'])
    db = get_db()
    db.execute('INSERT INTO produto (nome, preco) VALUES (?, ?)', (nome, preco))
    db.commit()
    flash('Produto criado!', 'success')
    return redirect(url_for('main.listar_produtos'))
```

---

## 4. Upload de Arquivos

```python
import os, uuid
from werkzeug.utils import secure_filename
from flask import current_app

EXTENSOES_IMAGEM = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
EXTENSOES_DOCUMENTO = {'pdf', 'docx', 'xlsx', 'csv', 'txt'}

def salvar_arquivo(arquivo, pasta='uploads', extensoes_permitidas=None):
    """Salva arquivo enviado com nome seguro e UUID. Retorna nome salvo ou None."""
    if not arquivo or arquivo.filename == '':
        return None
    extensao = arquivo.filename.rsplit('.', 1)[-1].lower() if '.' in arquivo.filename else ''
    if extensoes_permitidas and extensao not in extensoes_permitidas:
        return None
    nome = f"{uuid.uuid4().hex}.{extensao}"
    caminho = os.path.join(current_app.config['UPLOAD_FOLDER'], pasta, nome)
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    arquivo.save(caminho)
    return nome

@main_bp.route('/produto/novo', methods=['POST'])
@login_required
def novo_produto():
    nome = request.form['nome']
    foto = request.files.get('foto')
    nome_foto = salvar_arquivo(foto, 'produtos', EXTENSOES_IMAGEM)

    db = get_db()
    db.execute(
        'INSERT INTO produto (nome, foto) VALUES (?, ?)',
        (nome, nome_foto)
    )
    db.commit()
    flash('Produto criado com foto!', 'success')
    return redirect(url_for('main.listar_produtos'))
```

---

## 5. Erros Customizados

```python
# app/__init__.py
def register_error_handlers(app):
    @app.errorhandler(400)
    def bad_request(e):
        if request.is_json or request.path.startswith('/api/'):
            return jsonify({'erro': 'Requisição inválida', 'detalhe': str(e)}), 400
        return render_template('errors/400.html'), 400

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/403.html'), 403

    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith('/api/'):
            return jsonify({'erro': 'Recurso não encontrado'}), 404
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception('Erro 500')
        if request.is_json:
            return jsonify({'erro': 'Erro interno do servidor'}), 500
        return render_template('errors/500.html'), 500
```

---

## 6. Paginação Manual

```python
class Paginacao:
    """Helper de paginação para uso com SQLite puro."""
    def __init__(self, total, pagina, por_pagina):
        self.total = total
        self.page = pagina
        self.per_page = por_pagina
        self.pages = max(1, -(-total // por_pagina))  # ceil division
        self.has_prev = pagina > 1
        self.has_next = pagina < self.pages
        self.prev_num = pagina - 1
        self.next_num = pagina + 1

    def iter_pages(self, left_edge=1, right_edge=1, left_current=2, right_current=2):
        last = 0
        for num in range(1, self.pages + 1):
            if (num <= left_edge or
                (self.page - left_current <= num <= self.page + right_current) or
                num > self.pages - right_edge):
                if last + 1 != num:
                    yield None
                yield num
                last = num

# Uso
@main_bp.route('/produtos')
def listar_produtos():
    pagina = request.args.get('pagina', 1, type=int)
    por_pagina = 12
    db = get_db()
    total = db.execute('SELECT COUNT(*) FROM produto WHERE ativo=1').fetchone()[0]
    offset = (pagina - 1) * por_pagina
    produtos = db.execute(
        'SELECT * FROM produto WHERE ativo=1 LIMIT ? OFFSET ?',
        (por_pagina, offset)
    ).fetchall()
    paginacao = Paginacao(total, pagina, por_pagina)
    return render_template('main/produtos.html', produtos=produtos, pagination=paginacao)
```

---

## 7. JavaScript + Fetch com Flask

```python
# View que retorna JSON para chamada AJAX
@main_bp.route('/api/buscar-produtos')
def buscar_produtos_ajax():
    termo = request.args.get('q', '')
    produtos = Produto.query.filter(Produto.nome.ilike(f'%{termo}%')).limit(10).all()
    return jsonify([{'id': p.id, 'nome': p.nome, 'preco': p.preco} for p in produtos])
```

```javascript
// static/js/main.js
// Busca com debounce
let timer;
document.getElementById('busca').addEventListener('input', function() {
    clearTimeout(timer);
    timer = setTimeout(() => buscarProdutos(this.value), 300);
});

async function buscarProdutos(termo) {
    const url = `/api/buscar-produtos?q=${encodeURIComponent(termo)}`;
    const resp = await fetch(url);
    const produtos = await resp.json();

    const lista = document.getElementById('resultados');
    lista.innerHTML = produtos.map(p =>
        `<li>${p.nome} — R$ ${p.preco.toFixed(2)}</li>`
    ).join('');
}

// POST com CSRF token (WTForms ou manual)
async function salvarItem(dados) {
    const resp = await fetch('/api/produto', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.cookie.match(/csrf_token=([^;]+)/)?.[1] || ''
        },
        body: JSON.stringify(dados)
    });
    if (!resp.ok) throw new Error(await resp.text());
    return resp.json();
}
```
