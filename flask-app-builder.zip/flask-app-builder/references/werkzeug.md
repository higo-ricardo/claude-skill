# Werkzeug Reference

Werkzeug é o kit WSGI que alimenta o Flask. Geralmente é usado indiretamente via `flask.request` e `flask.Response`, mas alguns utilitários são acessados diretamente.

## 1. Segurança de Uploads

```python
from werkzeug.utils import secure_filename
import os

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'csv'}

def extensao_permitida(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['POST'])
def upload():
    if 'arquivo' not in request.files:
        flash('Nenhum arquivo enviado', 'danger')
        return redirect(request.url)

    arquivo = request.files['arquivo']

    if arquivo.filename == '':
        flash('Arquivo sem nome', 'danger')
        return redirect(request.url)

    if arquivo and extensao_permitida(arquivo.filename):
        nome_seguro = secure_filename(arquivo.filename)
        # Adicionar UUID para evitar conflitos
        import uuid
        nome_final = f"{uuid.uuid4().hex}_{nome_seguro}"
        arquivo.save(os.path.join(app.config['UPLOAD_FOLDER'], nome_final))
        flash('Arquivo enviado com sucesso!', 'success')
        return redirect(url_for('main.index'))
```

## 2. Hashing de Senhas

```python
from werkzeug.security import generate_password_hash, check_password_hash

# Criar hash (use na criação de conta)
hash_senha = generate_password_hash('minha_senha_segura')
# → 'scrypt:32768:8:1$salt$hash...'

# Verificar senha (use no login)
if check_password_hash(hash_senha, senha_digitada):
    # senha correta
    pass

# Exemplo em modelo de usuário
class Usuario:
    def set_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

    def verificar_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)
```

## 3. Utilitários de URL

```python
from werkzeug.urls import url_encode, url_decode

# Codificar query string
params = url_encode({'busca': 'flask tutorial', 'pagina': 2})
# → 'busca=flask+tutorial&pagina=2'

# Decodificar query string
dados = url_decode('nome=jo%C3%A3o&idade=30')
# → MultiDict([('nome', 'joão'), ('idade', '30')])
```

## 4. HTTP Exceptions (abortar com estilo)

```python
from werkzeug.exceptions import NotFound, Forbidden, BadRequest, Unauthorized

# Jeito Flask
from flask import abort
abort(404)           # levanta NotFound
abort(403)           # levanta Forbidden
abort(400)           # levanta BadRequest

# Capturar em handler
@app.errorhandler(404)
def pagina_nao_encontrada(e):
    return render_template('errors/404.html'), 404

@app.errorhandler(403)
def acesso_negado(e):
    return render_template('errors/403.html'), 403

# Abortar com mensagem personalizada
from werkzeug.exceptions import NotFound
raise NotFound(description='Produto não encontrado no catálogo.')
```

## 5. Response Headers e Cache

```python
from flask import make_response

# Desabilitar cache (útil para APIs e dados sensíveis)
@app.after_request
def sem_cache(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    return response

# Forçar download de arquivo
@app.route('/baixar/<nome>')
def baixar(nome):
    resp = make_response(open(f'uploads/{nome}', 'rb').read())
    resp.headers['Content-Disposition'] = f'attachment; filename="{nome}"'
    resp.headers['Content-Type'] = 'application/octet-stream'
    return resp

# Enviar arquivo com send_file
from flask import send_file, send_from_directory

@app.route('/arquivo/<nome>')
def servir_arquivo(nome):
    return send_from_directory(app.config['UPLOAD_FOLDER'], nome)
```

## 6. Local Proxy e Contexto de Request

```python
# Flask usa LocalProxy para request, session, g, current_app
# Nunca importe esses objetos fora do contexto de request
from flask import request, current_app, g

# Acessar app fora de request (ex: script, CLI)
with app.app_context():
    # aqui você tem acesso a current_app, g, etc.
    db = conectar_banco()
```

## 7. Test Client

```python
# Testar rotas sem servidor
with app.test_client() as client:
    # GET
    resp = client.get('/produtos')
    assert resp.status_code == 200

    # POST com form
    resp = client.post('/login', data={
        'email': 'user@test.com',
        'senha': '123456'
    }, follow_redirects=True)

    # POST com JSON
    resp = client.post('/api/produto', json={'nome': 'Caneta', 'preco': 2.50})
    dados = resp.get_json()

    # Com sessão
    with client.session_transaction() as sess:
        sess['usuario_id'] = 1
```

## 8. Datastructures Úteis

```python
from werkzeug.datastructures import FileStorage, MultiDict, ImmutableMultiDict

# MultiDict: permite múltiplos valores por chave
# request.form, request.args e request.files são MultiDict

# Acessar todos valores de um campo multi-select
ids = request.form.getlist('produto_ids')  # → ['1', '2', '3']

# FileStorage: objeto de arquivo enviado
arquivo = request.files['foto']
arquivo.filename      # nome original
arquivo.content_type  # MIME type
arquivo.save('/tmp/foto.jpg')
stream = arquivo.stream  # acesso direto ao stream
```
