# Click CLI Reference — Integração com Flask

## 1. Comandos Flask via app.cli

```python
# app/__init__.py ou cli.py
import click
from flask import Flask
from . import create_app

app = create_app()

# Comando simples
@app.cli.command('iniciar-db')
def iniciar_db():
    """Cria todas as tabelas do banco de dados."""
    from .extensions import db
    db.create_all()
    click.echo('Banco de dados inicializado!')

# Comando com argumento
@app.cli.command('criar-usuario')
@click.argument('email')
@click.option('--papel', default='user', help='Papel do usuário (user/admin)')
@click.option('--senha', prompt=True, hide_input=True, confirmation_prompt=True)
def criar_usuario(email, papel, senha):
    """Cria um novo usuário no sistema."""
    from .models import Usuario
    from .extensions import db
    from werkzeug.security import generate_password_hash

    usuario = Usuario(
        email=email,
        papel=papel,
        senha_hash=generate_password_hash(senha)
    )
    db.session.add(usuario)
    db.session.commit()
    click.echo(click.style(f'Usuário {email} criado com papel {papel}!', fg='green'))

# Executar
# flask iniciar-db
# flask criar-usuario admin@site.com --papel admin
```

## 2. Grupos de Comandos

```python
import click
from flask import Blueprint

# Via blueprint (organiza comandos por módulo)
admin_bp = Blueprint('admin', __name__)

@admin_bp.cli.group()
def admin():
    """Comandos administrativos."""
    pass

@admin.command('listar-usuarios')
@click.option('--papel', default=None, help='Filtrar por papel')
def listar_usuarios(papel):
    """Lista todos os usuários."""
    from .models import Usuario
    query = Usuario.query
    if papel:
        query = query.filter_by(papel=papel)

    usuarios = query.all()
    if not usuarios:
        click.echo('Nenhum usuário encontrado.')
        return

    for u in usuarios:
        click.echo(f'[{u.id}] {u.email} — {u.papel}')

# flask admin listar-usuarios
# flask admin listar-usuarios --papel admin
```

## 3. Opções e Tipos Click

```python
@app.cli.command('exportar')
@click.option('--formato', type=click.Choice(['csv', 'json', 'xlsx']), default='csv')
@click.option('--limite', type=int, default=1000, show_default=True)
@click.option('--verbose', is_flag=True, help='Saída detalhada')
@click.option('--saida', type=click.Path(), default='exportacao.csv', help='Arquivo de saída')
@click.confirmation_option(prompt='Confirma a exportação?')
def exportar(formato, limite, verbose, saida):
    """Exporta dados para arquivo."""
    if verbose:
        click.echo(f'Exportando {limite} registros em formato {formato}...')

    # lógica de exportação...
    click.echo(click.style(f'✓ Exportado para {saida}', fg='green'))
```

## 4. Progress Bar e Interatividade

```python
@app.cli.command('processar')
@click.argument('arquivo', type=click.File('r'))
def processar(arquivo):
    """Processa um arquivo de dados."""
    linhas = arquivo.readlines()

    with click.progressbar(linhas, label='Processando') as barra:
        for linha in barra:
            processar_linha(linha)

    click.echo(f'\n{len(linhas)} linhas processadas.')

# Confirmação interativa
@app.cli.command('limpar-db')
def limpar_db():
    """PERIGO: apaga todos os dados."""
    if click.confirm('Tem certeza que quer apagar TODOS os dados?', default=False):
        db.drop_all()
        db.create_all()
        click.echo(click.style('Banco resetado.', fg='yellow'))
    else:
        click.echo('Operação cancelada.')
```

## 5. Saída Colorida e Formatada

```python
# Cores disponíveis: black, red, green, yellow, blue, magenta, cyan, white
click.echo(click.style('✓ Sucesso', fg='green', bold=True))
click.echo(click.style('✗ Erro', fg='red'))
click.echo(click.style('⚠ Aviso', fg='yellow'))
click.echo(click.style('ℹ Info', fg='cyan'))

# Tabela simples
def imprimir_tabela(colunas, linhas):
    larguras = [max(len(str(l[i])) for l in [colunas] + linhas) for i in range(len(colunas))]
    sep = '  '.join('-' * l for l in larguras)
    header = '  '.join(str(c).ljust(l) for c, l in zip(colunas, larguras))
    click.echo(header)
    click.echo(sep)
    for linha in linhas:
        click.echo('  '.join(str(v).ljust(l) for v, l in zip(linha, larguras)))
```

## 6. Variáveis de Ambiente com Click

```python
# Aceitar valor de variável de ambiente automaticamente
@app.cli.command()
@click.option('--db-url', envvar='DATABASE_URL', required=True)
@click.option('--api-key', envvar='API_KEY', required=True)
def sincronizar(db_url, api_key):
    """Sincroniza com API externa."""
    click.echo(f'Conectando em {db_url}...')
```

## 7. Registrar Comandos na Factory

```python
# app/__init__.py
def create_app():
    app = Flask(__name__)
    # ...
    register_commands(app)
    return app

def register_commands(app):
    from .commands import iniciar_db, criar_admin, popular_dados
    app.cli.add_command(iniciar_db)
    app.cli.add_command(criar_admin)
    app.cli.add_command(popular_dados)
```

```python
# app/commands.py
import click
from flask.cli import with_appcontext

@click.command('iniciar-db')
@with_appcontext
def iniciar_db():
    """Inicializa o banco de dados."""
    from .extensions import db
    db.create_all()
    click.echo('DB inicializado!')

@click.command('popular-dados')
@click.option('--quantidade', default=10, type=int)
@with_appcontext
def popular_dados(quantidade):
    """Popula o banco com dados de teste."""
    from .models import Produto
    from .extensions import db
    import random

    for i in range(quantidade):
        p = Produto(nome=f'Produto {i+1}', preco=round(random.uniform(10, 500), 2))
        db.session.add(p)
    db.session.commit()
    click.echo(f'{quantidade} produtos criados!')
```
