# Jinja2 Templates Reference

## 1. Herança de Templates (padrão essencial)

### base.html
```html
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Meu App{% endblock %}</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
    {% block head %}{% endblock %}
</head>
<body>
    {% include 'partials/_navbar.html' %}

    <main class="container">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }} alert-dismissible">
                        {{ message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        {% block content %}{% endblock %}
    </main>

    {% include 'partials/_footer.html' %}

    <script src="{{ url_for('static', filename='js/main.js') }}"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
```

### Página filha
```html
{% extends 'base.html' %}

{% block title %}Produtos — Meu App{% endblock %}

{% block content %}
<h1>Lista de Produtos</h1>
{% for produto in produtos %}
    {{ loop.index }}. {{ produto.nome }} — R$ {{ produto.preco | format_brl }}
{% endfor %}
{% endblock %}

{% block scripts %}
<script>
    // JS específico desta página
</script>
{% endblock %}
```

---

## 2. Sintaxe Jinja2

```jinja
{# Comentário — não aparece no HTML #}

{# Variável #}
{{ variavel }}
{{ usuario.nome }}
{{ dados['chave'] }}

{# Condicional #}
{% if usuario %}
    Olá, {{ usuario.nome }}!
{% elif visitante %}
    Bem-vindo!
{% else %}
    Faça login.
{% endif %}

{# Loop #}
{% for item in lista %}
    <li>{{ loop.index }}. {{ item.titulo }}</li>
{% else %}
    <li>Nenhum item encontrado.</li>
{% endfor %}

{# Variáveis do loop #}
loop.index       → 1, 2, 3 ...
loop.index0      → 0, 1, 2 ...
loop.first       → True no primeiro item
loop.last        → True no último item
loop.length      → total de itens
loop.revindex    → contagem regressiva

{# Set de variável local #}
{% set titulo = 'Painel' %}
{% set lista_nova = [] %}

{# Bloco raw (sem processamento Jinja) #}
{% raw %}
    {{ isso não é processado }}
{% endraw %}
```

---

## 3. Filtros Jinja2

```jinja
{# Filtros built-in essenciais #}
{{ nome | upper }}              → NOME
{{ nome | lower }}              → nome
{{ nome | title }}              → Nome
{{ nome | capitalize }}         → Nome
{{ texto | truncate(100) }}     → primeiros 100 chars...
{{ lista | length }}            → tamanho
{{ lista | join(', ') }}        → item1, item2, item3
{{ numero | round(2) }}         → 3.14
{{ preco | float }}             → float
{{ data | strftime('%d/%m/%Y') }}  → formatação de data
{{ html | safe }}               → render HTML sem escape
{{ None | default('N/A') }}     → N/A se None

{# Encadeamento #}
{{ nome | lower | title | truncate(30) }}
```

### Filtros customizados (Python)
```python
# app/__init__.py ou extensions.py
@app.template_filter('brl')
def format_brl(value):
    return f'R$ {value:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')

@app.template_filter('data_br')
def format_data_br(value):
    if value:
        return value.strftime('%d/%m/%Y')
    return ''

# No template
{{ produto.preco | brl }}        → R$ 1.299,90
{{ produto.criado_em | data_br }}  → 15/03/2024
```

---

## 4. Macros (componentes reutilizáveis)

```jinja
{# templates/macros/forms.html #}
{% macro campo_texto(nome, label, valor='', tipo='text', obrigatorio=False) %}
<div class="form-group mb-3">
    <label for="{{ nome }}" class="form-label">
        {{ label }}
        {% if obrigatorio %}<span class="text-danger">*</span>{% endif %}
    </label>
    <input
        type="{{ tipo }}"
        id="{{ nome }}"
        name="{{ nome }}"
        value="{{ valor }}"
        class="form-control"
        {% if obrigatorio %}required{% endif %}
    >
</div>
{% endmacro %}

{% macro botao(texto, tipo='button', classe='btn-primary') %}
<button type="{{ tipo }}" class="btn {{ classe }}">{{ texto }}</button>
{% endmacro %}

{% macro card(titulo, subtitulo='') %}
<div class="card mb-3">
    <div class="card-header">
        <h5 class="mb-0">{{ titulo }}</h5>
        {% if subtitulo %}<small class="text-muted">{{ subtitulo }}</small>{% endif %}
    </div>
    <div class="card-body">
        {{ caller() }}
    </div>
</div>
{% endmacro %}
```

```jinja
{# Usar macros em outro template #}
{% from 'macros/forms.html' import campo_texto, botao, card %}

{% call card('Novo Produto', 'Preencha os dados') %}
<form method="post">
    {{ campo_texto('nome', 'Nome do Produto', obrigatorio=True) }}
    {{ campo_texto('preco', 'Preço', tipo='number') }}
    {{ botao('Salvar', tipo='submit') }}
</form>
{% endcall %}
```

---

## 5. Context Processors (variáveis globais nos templates)

```python
# Disponível em TODOS os templates automaticamente
@app.context_processor
def variaveis_globais():
    return {
        'app_nome': 'Meu Sistema',
        'ano_atual': datetime.now().year,
        'usuario_logado': session.get('usuario_id'),
    }

# Context processor no blueprint
@main_bp.context_processor
def blueprint_context():
    return {'secao': 'principal'}
```

---

## 6. Includes e Partials

```
templates/
├── base.html
├── partials/
│   ├── _navbar.html
│   ├── _footer.html
│   ├── _sidebar.html
│   └── _pagination.html
├── macros/
│   ├── forms.html
│   └── cards.html
└── main/
    ├── index.html
    └── produto.html
```

```jinja
{# Include simples #}
{% include 'partials/_navbar.html' %}

{# Include com variável local #}
{% include 'partials/_alert.html' ignore missing %}

{# Passar variável para include #}
{% with mensagem = 'Salvo!', tipo = 'success' %}
    {% include 'partials/_flash.html' %}
{% endwith %}
```

---

## 7. Partial: Paginação

```jinja
{# templates/partials/_pagination.html #}
{% if pagination.pages > 1 %}
<nav aria-label="Paginação">
    <ul class="pagination justify-content-center">
        {% if pagination.has_prev %}
            <li class="page-item">
                <a class="page-link" href="{{ url_for(request.endpoint, pagina=pagination.prev_num, **request.args) }}">Anterior</a>
            </li>
        {% endif %}

        {% for p in pagination.iter_pages(left_edge=1, right_edge=1, left_current=2, right_current=2) %}
            {% if p %}
                <li class="page-item {% if p == pagination.page %}active{% endif %}">
                    <a class="page-link" href="{{ url_for(request.endpoint, pagina=p, **request.args) }}">{{ p }}</a>
                </li>
            {% else %}
                <li class="page-item disabled"><span class="page-link">…</span></li>
            {% endif %}
        {% endfor %}

        {% if pagination.has_next %}
            <li class="page-item">
                <a class="page-link" href="{{ url_for(request.endpoint, pagina=pagination.next_num, **request.args) }}">Próxima</a>
            </li>
        {% endif %}
    </ul>
</nav>
{% endif %}
```

---

## 8. Autoescaping e HTML Seguro

```jinja
{# Autoescaping está ATIVO por padrão em .html #}
{{ usuario_input }}         ← seguro: & < > " ' são escapados

{# Marcar string como segura (use com cuidado!) #}
{{ conteudo_html | safe }}

{# Bloco sem escape #}
{% autoescape false %}
    {{ html_confiavel }}
{% endautoescape %}
```

```python
# Python: Markup para strings seguras
from markupsafe import Markup, escape

@app.template_filter('destaque')
def destaque(s, termo):
    s = escape(s)
    termo = escape(termo)
    return Markup(str(s).replace(str(termo), f'<mark>{termo}</mark>'))
```
