# Flask Core Reference

## 1. Instância da Aplicação

```python
from flask import Flask

# Padrão simples
app = Flask(__name__)

# Com configurações customizadas
app = Flask(
    __name__,
    static_folder='static',        # pasta de arquivos estáticos
    static_url_path='/assets',     # URL para arquivos estáticos
    template_folder='templates',   # pasta de templates
    instance_relative_config=True  # config relativa à pasta /instance
)
```

## 2. Configuração

```python
# config.py — separar por ambiente
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-insecure')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class DevelopmentConfig(Config):
    DEBUG = True
    DATABASE = 'dev.db'

class ProductionConfig(Config):
    DATABASE = os.environ.get('DATABASE_URL')

# Carregar config na factory
def create_app(config_name='development'):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(f'app.config.{config_name.capitalize()}Config')
    app.config.from_pyfile('config.py', silent=True)  # instance/config.py
    return app
```

**Chaves de configuração importantes:**

| Chave | Descrição |
|---|---|
| `SECRET_KEY` | Assina cookies/sessões — **obrigatório em produção** |
| `DEBUG` | Modo debug com reloader e debugger |
| `TESTING` | Ativa modo de testes |
| `DATABASE_URI` | String de conexão do banco |
| `MAX_CONTENT_LENGTH` | Tamanho máximo de upload (ex: `16 * 1024 * 1024`) |
| `SESSION_COOKIE_SECURE` | Apenas HTTPS para cookies |
| `SEND_FILE_MAX_AGE_DEFAULT` | Cache de arquivos estáticos |

---

## 3. Factory Pattern + Blueprints

```python
# app/__init__.py
from flask import Flask
from .extensions import db, login_manager
from .blueprints.main import main_bp
from .blueprints.auth import auth_bp

def create_app(config_name='development'):
    app = Flask(__name__, instance_relative_config=True)

    # Config
    app.config.from_object(f'app.config.{config_name.title()}Config')

    # Extensões
    db.init_app(app)
    login_manager.init_app(app)

    # Blueprints
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix='/auth')

    # Handlers de erro
    register_error_handlers(app)

    return app

def register_error_handlers(app):
    @app.errorhandler(404)
    def not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template('errors/500.html'), 500
```

```python
# app/blueprints/main/__init__.py
from flask import Blueprint
main_bp = Blueprint('main', __name__, template_folder='templates')
from . import routes  # importa após criar blueprint
```

---

## 4. Rotas e Views

```python
from flask import (
    request, render_template, redirect, url_for,
    flash, jsonify, abort, make_response, session, g
)

# GET simples
@main_bp.route('/')
def index():
    return render_template('main/index.html')

# GET + POST
@main_bp.route('/contato', methods=['GET', 'POST'])
def contato():
    if request.method == 'POST':
        nome = request.form.get('nome')
        flash(f'Mensagem de {nome} recebida!', 'success')
        return redirect(url_for('main.index'))
    return render_template('main/contato.html')

# Parâmetro dinâmico com tipos
@main_bp.route('/produto/<int:id>')
def produto(id):
    item = buscar_produto(id)
    if not item:
        abort(404)
    return render_template('main/produto.html', item=item)

# Conversor de rota personalizado
# string | int | float | path | uuid
@main_bp.route('/arquivo/<path:caminho>')
def arquivo(caminho):
    return f'Arquivo: {caminho}'

# View baseada em classe (MethodView)
from flask.views import MethodView

class ProdutoView(MethodView):
    def get(self, id=None):
        if id is None:
            return jsonify(listar_produtos())
        return jsonify(buscar_produto(id))

    def post(self):
        dados = request.get_json()
        novo = criar_produto(dados)
        return jsonify(novo), 201

    def put(self, id):
        dados = request.get_json()
        atualizado = atualizar_produto(id, dados)
        return jsonify(atualizado)

    def delete(self, id):
        deletar_produto(id)
        return '', 204

# Registrar MethodView
produto_view = ProdutoView.as_view('produto')
app.add_url_rule('/api/produtos', view_func=produto_view, methods=['GET', 'POST'])
app.add_url_rule('/api/produtos/<int:id>', view_func=produto_view, methods=['GET', 'PUT', 'DELETE'])
```

---

## 5. Request Object (Werkzeug)

```python
# Dados do formulário
nome = request.form.get('nome', '')          # campo de form
arquivo = request.files.get('foto')          # upload

# Query string (?busca=flask&pagina=2)
busca = request.args.get('busca', '')
pagina = request.args.get('pagina', 1, type=int)

# JSON body
dados = request.get_json()                   # dict ou None
dados = request.get_json(force=True)         # ignora Content-Type

# Cabeçalhos e metadados
token = request.headers.get('Authorization')
ip = request.remote_addr
metodo = request.method                      # 'GET', 'POST', etc.
url_atual = request.url
endpoint = request.endpoint

# Verificar método
if request.method == 'POST': ...
if request.is_json: ...
```

---

## 6. Response Object

```python
# Retorno simples (Flask cria Response automaticamente)
return 'Olá mundo'                           # texto/html
return render_template('pagina.html')        # HTML via Jinja
return jsonify({'status': 'ok', 'id': 1})   # JSON (Content-Type: application/json)
return redirect(url_for('main.index'))       # redirect 302
return redirect(url_for('main.index'), 301)  # redirect permanente

# Resposta com status customizado
return render_template('erro.html'), 422

# Resposta manual completa
from flask import make_response
resp = make_response(render_template('pagina.html'))
resp.headers['X-Custom'] = 'valor'
resp.set_cookie('usuario', 'joao', max_age=3600, httponly=True)
return resp

# JSON com status
return jsonify({'erro': 'não encontrado'}), 404

# Streaming
from flask import stream_template
@app.get('/timeline')
def timeline():
    return stream_template('timeline.html', itens=gerar_itens())
```

---

## 7. Sessões

```python
from flask import session

# Gravar na sessão
session['usuario_id'] = 42
session['preferencias'] = {'tema': 'escuro'}

# Ler da sessão
usuario_id = session.get('usuario_id')

# Remover da sessão
session.pop('usuario_id', None)

# Tornar permanente (usa PERMANENT_SESSION_LIFETIME)
session.permanent = True

# Limpar tudo
session.clear()
```

---

## 8. `g` — Contexto Global por Request

```python
from flask import g

# Guardar dados no ciclo de vida do request
def obter_db():
    if 'db' not in g:
        g.db = conectar_banco()
    return g.db

@app.teardown_appcontext
def fechar_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()
```

---

## 9. Flash Messages

```python
# View
from flask import flash
flash('Salvo com sucesso!', 'success')
flash('Erro ao salvar!', 'danger')
flash('Atenção: campo vazio.', 'warning')

# Template (categorias: success | danger | warning | info)
{% with messages = get_flashed_messages(with_categories=true) %}
  {% for category, message in messages %}
    <div class="alert alert-{{ category }}">{{ message }}</div>
  {% endfor %}
{% endwith %}
```

---

## 10. Decoradores de View (padrões comuns)

```python
from functools import wraps
from flask import session, redirect, url_for, abort

# Requer login
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'usuario_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated

# Requer papel/permissão
def requer_papel(papel):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            usuario = session.get('papel')
            if usuario != papel:
                abort(403)
            return f(*args, **kwargs)
        return decorated
    return decorator

# Uso
@main_bp.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@main_bp.route('/admin')
@login_required
@requer_papel('admin')
def painel_admin():
    return render_template('admin.html')
```

---

## 11. Hooks do Ciclo de Vida

```python
@app.before_request
def carregar_usuario():
    g.usuario = Usuario.query.get(session.get('usuario_id'))

@app.after_request
def adicionar_headers(response):
    response.headers['X-Frame-Options'] = 'DENY'
    return response

@app.teardown_appcontext
def fechar_db(e=None):
    db = g.pop('db', None)
    if db: db.close()

# Apenas em blueprint
@main_bp.before_request
def verificar_acesso():
    if not g.usuario:
        return redirect(url_for('auth.login'))
```

---

## 12. URL Building

```python
# Sempre use url_for() em vez de strings hardcoded
url_for('main.index')                         # → /
url_for('main.produto', id=5)                 # → /produto/5
url_for('static', filename='css/style.css')   # → /static/css/style.css
url_for('main.busca', q='flask', pagina=2)    # → /busca?q=flask&pagina=2
url_for('main.index', _external=True)         # URL absoluta com domínio
url_for('main.index', _scheme='https')        # força HTTPS
```
