---
name: flask-app-builder
description: >
  Arquitetura de referência e guia completo para criar aplicações web em Python com Flask (3.1.x),
  usando Werkzeug, Jinja2 e Click. Cobre qualquer domínio de negócio. Use esta skill SEMPRE que o
  usuário quiser: criar um app Flask do zero; adicionar rota, blueprint ou view; implementar
  autenticação, formulários, upload de arquivos, API REST ou páginas com templates Jinja2;
  criar comandos CLI com Click; configurar banco de dados (SQLite ou SQLAlchemy); implementar
  flash messages, sessões, decoradores de view, tratamento de erros, streaming ou contexto global.
  Também use para estruturar projetos Flask grandes com blueprints, factory pattern, camadas de
  serviço e layout de pastas. Exemplos de gatilhos: "criar app web com Flask", "adicionar rota
  protegida", "template base com herança Jinja", "API JSON com Flask", "upload de arquivo",
  "login com sessão", "formulário WTForms", "comando CLI personalizado".
---

# Flask App Builder

Skill completa para construção de aplicações web com **Flask 3.1.x**, integrando Werkzeug, Jinja2 e Click.

## Fluxo de Trabalho

1. **Entender o domínio** — tipo do app (CRUD, API, painel, etc.) e recursos necessários
2. **Definir estrutura** — app simples vs. factory pattern com blueprints
3. **Gerar o código** — routes, templates, modelos, CLI, configs
4. **Validar** — checar segurança, padrões e boas práticas

---

## Escolhendo a Estrutura

| Cenário | Estrutura recomendada |
|---|---|
| Script único / demo | `app.py` direto |
| App médio com seções | Factory + Blueprints |
| API REST | Blueprint de API + `jsonify` |
| Painel admin | Blueprint `admin` + autenticação |

---

## Estrutura de Projeto (Factory Pattern — Recomendado)

```
meu_app/
├── app/
│   ├── __init__.py          ← create_app() factory
│   ├── config.py            ← configurações por ambiente
│   ├── models.py            ← modelos de dados
│   ├── extensions.py        ← extensões (db, login, etc.)
│   ├── blueprints/
│   │   ├── main/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── forms.py
│   │   └── auth/
│   │       ├── __init__.py
│   │       └── routes.py
│   ├── templates/
│   │   ├── base.html        ← layout base Jinja2
│   │   ├── main/
│   │   └── auth/
│   └── static/
│       ├── css/
│       └── js/
├── instance/
│   └── config.py            ← segredos (não versionado)
├── migrations/
├── tests/
├── cli.py                   ← comandos Click
├── run.py                   ← ponto de entrada dev
└── requirements.txt
```

---

## Referências Disponíveis

Leia os arquivos abaixo conforme a necessidade da tarefa:

| Arquivo | Conteúdo |
|---|---|
| `references/core.md` | Flask core: rotas, request, response, sessões, g, blueprints |
| `references/jinja2.md` | Templates Jinja2: herança, filtros, macros, componentes |
| `references/werkzeug.md` | Werkzeug: Request/Response, routing, utilitários de segurança |
| `references/click_cli.md` | Click: comandos CLI, grupos, opções, integração Flask |
| `references/patterns.md` | Padrões: auth, upload, API REST, erros, contexto, SQLite |
| `assets/templates/` | Templates HTML prontos (base, login, CRUD, API) |
| `assets/components/` | Componentes Python reutilizáveis (decoradores, helpers) |

**Regra:** ao iniciar qualquer tarefa Flask, leia `references/core.md` primeiro. Depois leia os demais conforme relevância.

---

## Checklist de Qualidade

Antes de entregar qualquer código Flask, verifique:

- [ ] `SECRET_KEY` vem de variável de ambiente, nunca hardcoded
- [ ] Dados de usuário passam por `escape()` ou templates Jinja (autoescaping ativo)
- [ ] Uploads validam extensão com `ALLOWED_EXTENSIONS` e usam `secure_filename()`
- [ ] Rotas POST têm proteção CSRF (WTForms ou token manual)
- [ ] Erros 404 e 500 têm handlers customizados
- [ ] Banco de dados usa `g` ou `teardown_appcontext` para fechar conexões
- [ ] `url_for()` é usado em vez de URLs hardcoded
- [ ] Debug mode **desativado** em produção

---

## Comandos Essenciais

```bash
# Instalar
pip install flask

# Rodar em dev
flask --app app run --debug

# Rodar exposto na rede
flask --app app run --host=0.0.0.0 --debug

# Comandos CLI customizados
flask --app app meu-comando

# Variáveis de ambiente (dev)
export FLASK_APP=app
export FLASK_ENV=development
export SECRET_KEY=chave-super-secreta
```
